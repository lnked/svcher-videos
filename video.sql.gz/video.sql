-- Adminer 4.6.2 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP DATABASE IF EXISTS `video`;
CREATE DATABASE `video` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */;
USE `video`;

DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `system` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `system` (`system`),
  KEY `system_index` (`system`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `settings` (`id`, `system`, `value`) VALUES
(2,	'event_name',	'Новое мероприятие'),
(3,	'mode',	'video'),
(4,	'password',	'153426rhfy'),
(5,	'time',	'3.5'),
(6,	'send_button',	'Отправить на почту'),
(7,	'send_email',	'timefreeze23@softkor.ru'),
(8,	'send_password',	'153426rhfy'),
(9,	'send_server',	'smtp.mail.ru'),
(10,	'send_port',	'465'),
(11,	'send_signature',	'С уважением,\r\nАдминистрация мероприятия'),
(12,	'pathname',	'/Volumes/Untitled/Users/lnked/web/video.dev/input'),
(23,	'login',	'admin'),
(25,	'send_name',	'ООО «СОФТКОР»'),
(26,	'send_subject',	'Видео с мероприятия'),
(28,	'logo',	'/cache/logo.png'),
(29,	'style_body_bg',	'#0de0af'),
(30,	'style_body_text',	'#0d7567'),
(31,	'style_sidebar_bg',	'#758cff'),
(32,	'style_sidebar_text',	'#040078'),
(33,	'style_button_bg',	'#671799'),
(34,	'style_button_text',	'#ffffff'),
(35,	'send_photo_number',	'06');

DROP TABLE IF EXISTS `statistics`;
CREATE TABLE `statistics` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `datetime` int(11) NOT NULL,
  `session` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `statistics` (`id`, `datetime`, `session`, `name`, `email`, `phone`) VALUES
(1,	1522928362,	'session_2018_04_01_15_08_57',	'ed',	'ed.proff@gmail.com',	'+7 988 77734 34'),
(2,	1522928572,	'session_2018_04_01_15_21_24',	'Сергей',	'svcher@bk.ru',	'+7 988 666 77 66'),
(3,	1522954195,	'session_2018_04_01_15_08_57',	'тест',	'ed.proff@gmail.com',	'+79884343434'),
(60,	1522964290,	'session_2018_04_01_13_43_21',	'ed',	'ed.proff@gmail.com',	'+7 988 666 77 66'),
(61,	1523022707,	'session_2018_04_01_14_53_08',	'ed',	'dobrenkiy@softkor.ru',	'+7 (798) 866-67-76'),
(62,	1523457928,	'session_2018_04_01_13_43_21',	'ed',	'ed.proff@gmail.com',	'+7 988 666 77 66');

-- 2018-04-11 14:49:22
